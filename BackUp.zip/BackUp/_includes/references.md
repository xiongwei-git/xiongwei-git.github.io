
[Disqus]: http://disqus.com/
[elf+js]: http://elfjs.com/
[ER]: http://www.errorrik.com/er/
[GitHub]: https://github.com/
[Google Custom Search]: http://www.google.com/cse/
[Google Picasa]: https://picasaweb.google.com/
[Gravatar]: http://gravatar.com/
[HighlightJS]: http://softwaremaniacs.org/soft/highlight/en/
[jekyll]: https://github.com/mojombo/jekyll
[JSDuck]: https://github.com/senchalabs/jsduck
[jslib]: https://github.com/elfjs/jslib/
[jslib-builder]: http://github.com/elfjs/jslib-builder/
[Markdown]: http://daringfireball.net/projects/markdown/
[WordPress]: http://wordpress.org/
[MrXiong]: http://mrxiong.com/
