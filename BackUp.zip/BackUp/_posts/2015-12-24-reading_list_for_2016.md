---
layout: post
title: 2015-2016年读书计划清单
category: blog
---

读书务在循序渐进；一书已熟，方读一书，勿得卤莽躐等，虽多无益。　——胡居仁

---

### 2015-2016年读书计划清单  
| 书名      |    完成度 | 读书笔记  |  
| :-------- | --------:| :--: |  
| Android应用UI设计模式 |  100% | loading  |  
| 群山回唱  | 45% |  loading   |  
| Android群英传 |   35%  |  loading |  
| 大话设计模式 |    30% | loading  |  
| Head First 设计模式 |  20% | loading  |  
| 深入理解Java虚拟机 |    10% | loading  |  
| Android应用性能优化 |    0% | loading  |  